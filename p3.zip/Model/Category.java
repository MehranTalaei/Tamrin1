package Model;

public class Category {
    String name;
    String restaurant;
}
