package Model;

import java.util.ArrayList;

public class Customer extends User {
    int balance;

    ArrayList<Discount> discounts = new ArrayList<>();
    ArrayList<FoodOrdered> Cart = new ArrayList<>();

    public void addDisccout(Discount discount) {
        discounts.add(discount);
    }

    public void addToCart(FoodOrdered foodOrdered) {
        Cart.add(foodOrdered);
    }

    public FoodOrdered FindFood(Food food) {
        for (int i = 0; i < Cart.size(); i++) {
            if (Cart.get(i).getFood().equals(food)) {
                return Cart.get(i);
            }
        }
        return null;
    }


    public ArrayList<Discount> getDiscounts() {
        return discounts;
    }

    public ArrayList<FoodOrdered> getCart() {
        return Cart;
    }

    public Customer(String username, String password) {
        super(username, password);
    }

    public int GetTotalPriceOfCart() {
        int ans = 0;
        for (FoodOrdered foodOrdered : Cart) {
            ans += foodOrdered.number * foodOrdered.getFood().getPrice();
        }
        return  ans;
    }

    public int GetTotalCostOfCart() {
        int ans = 0;
        for (FoodOrdered foodOrdered : Cart) {
            ans += foodOrdered.number * foodOrdered.getFood().getCost();
        }
        return  ans;
    }
    public Discount getDiscountByCode(String code) {
        for (int i = 0; i < discounts.size(); i++) {
            if (discounts.get(i).getCode().equals(code)) {
                return discounts.get(i);
            }
        }
        return null;
    }
}
