package Model;

import java.util.Objects;

public class FoodOrdered {
    Food food;
    Customer owner;
    int number;

    public FoodOrdered(Food food, Customer owner, int number) {
        this.food = food;
        this.owner = owner;
        this.number = number;
    }

    public Food getFood() {
        return food;
    }

    public Customer getOwner() {
        return owner;
    }

    public int getNumber() {
        return number;
    }

    public void increaseNumber(int n) {
        this.number += n;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        FoodOrdered that = (FoodOrdered) o;
        return number == that.number && Objects.equals(food, that.food) && Objects.equals(owner, that.owner);
    }

    @Override
    public int hashCode() {
        return Objects.hash(food, owner, number);
    }
}
