package Model;

public class SnappAdmin extends User {
    private static SnappAdmin instance;
    private SnappAdmin(String username, String password) {
        super(username, password);
    }

    public static SnappAdmin SetInstance(String username, String password) {
        if (instance == null) {
            instance = new SnappAdmin(username, password);
        }
        return instance;
    }

    public static SnappAdmin getInstance() {
        return instance;
    }
}
