package Model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Restaurant extends User {
    int balance;
    String type;
    ArrayList<Food> foods = new ArrayList<>();
    public static Set<String> categories = new HashSet<>();
    static {
        categories.add("entree");
        categories.add("dessert");
        categories.add("starter");
    }

    public Restaurant(String username, String password, String type) {
        super(username, password);
        this.type=type;
    }

    public Food getFoodByName(String name) {
        for (int i = 0; i < foods.size(); i++) {
            if (foods.get(i).getName().equals(name)) {
                return foods.get(i);
            }
        }
        return null;
    }


    public String getType() {
        return type;
    }

    public ArrayList<Food> getMenu() {
        return foods;
    }

}
