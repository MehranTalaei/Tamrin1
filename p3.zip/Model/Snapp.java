package Model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

public class Snapp {
    private static ArrayList<Restaurant> restaurants=new ArrayList<>();
    private static ArrayList<Customer> customers = new ArrayList<>();
    private static ArrayList<Discount> discounts = new ArrayList<>();
    public static Set<String> allMenu = new HashSet<>();
    static {
        allMenu.add("customer menu");
        allMenu.add("restaurant admin menu");
        allMenu.add("Snappfood admin menu");
    }
    public static void addRestaurant(Restaurant restaurant) {
        restaurants.add(restaurant);
    }

    public static void addCustomer(Customer customer) {
        customers.add(customer);
    }

    public static void addDiscount(Discount discount) {
        discounts.add(discount);
    }

    public static void removeRestaurant(Restaurant restaurant) {
        restaurants.remove(restaurant);
    }

    public static void removeCustomer(Customer customer) {
        customers.remove(customer);
    }

    public static Restaurant getRestaurantByname(String name) {
        for (int i = 0; i < restaurants.size(); i++) {
            if (restaurants.get(i).getUsername().equals(name)) {
                return restaurants.get(i);
            }
        }
        return null;
    }

    public static Customer getCustomerByName(String name) {
        for (int i = 0; i < customers.size(); i++) {
            if (customers.get(i).getUsername().equals(name)) {
                return customers.get(i);
            }
        }
        return null;
    }

    public static ArrayList<Restaurant> getRestaurants() {
        return restaurants;
    }

    public static ArrayList<Customer> getCustomers() {
        return customers;
    }

    public static ArrayList<Discount> getDiscounts() {
        return discounts;
    }

    public static User getUserByName(String name) {
        if (getCustomerByName(name) != null) {
            return getCustomerByName(name);
        }
        if (getRestaurantByname(name) != null) {
            return getRestaurantByname(name);
        }
        if (SnappAdmin.getInstance() != null && SnappAdmin.getInstance().getUsername().equals(name)) {
            return SnappAdmin.getInstance();
        }
        return null;
    }
}
