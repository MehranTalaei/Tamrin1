package Model;

public class Discount {
    Customer owner;
    String code;
    int amount;

    public Discount(Customer owner, String code,int amount) {
        this.owner = owner;
        this.code = code;
        this.amount=amount;
    }

    public Customer getOwner() {
        return owner;
    }

    public String getCode() {
        return code;
    }

    public int getAmount() {
        return amount;
    }
}
