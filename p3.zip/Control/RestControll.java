package Control;

import Model.Food;
import Model.Restaurant;
import Model.User;

import java.util.regex.Matcher;

public class RestControll {
    public static String Charge(Matcher matcher, User user) {
        matcher.find();
        int amount = Integer.parseInt(matcher.group("amount"));
        if (amount <= 0) {
            return "charge account failed: invalid cost or price";
        } else {
            user.increaseBalance(amount);
            return "charge account successful";
        }
    }

    public static String ShowBalance(Matcher matcher, User user) {
        matcher.find();
        return user.getBalance()+"";
    }

    public static String addFood(Matcher matcher, Restaurant restaurant) {
        matcher.find();
        String name = matcher.group("name");
        String category = matcher.group("category");
        int price = Integer.parseInt(matcher.group("price"));
        int cost = Integer.parseInt(matcher.group("cost"));
        if (!Restaurant.categories.contains(category)) {
            return "add food failed: invalid category";
        } else if (!name.matches("[a-z-]+")) {
            return "add food failed: invalid food name";
        } else if (restaurant.getMenu().contains(new Food(name, restaurant))) {
            return "add food failed: food already exists";
        } else if (cost <= 0 || price <= 0) {
            return "add food failed: invalid cost or price";
        } else {
            Food food = new Food(name, restaurant);
            food.setCost(cost);
            food.setPrice(price);
            food.setCategory(category);
            restaurant.getMenu().add(food);
            return "add food successful";
        }
    }

    public static String removeFood(Matcher matcher, Restaurant restaurant) {
        matcher.find();
        String name = matcher.group("name");
        if (!restaurant.getMenu().contains(new Food(name, restaurant))) {
            return "remove food failed: food not found";
        } else {
            restaurant.getMenu().remove(new Food(name, restaurant));
            return "";
        }
    }
}
