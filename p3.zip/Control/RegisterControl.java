package Control;

import Model.Customer;
import Model.Snapp;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterControl {
    public static String register(Matcher matcher) {
        matcher.find();
        String username = matcher.group("username");
        String password = matcher.group("password");
        if (!username.matches("\\w+")) {
            return "register failed: invalid username format";
        } else if (username.matches("[0-9_]+")) {
            return "register failed: invalid username format";
        } else if (Snapp.getUserByName(username) != null) {
            return "register failed: username already exists";
        } else if (!password.matches("\\w+")) {
            return "register failed: invalid password format";
        } else if (!password.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{5,}$")) {
            return "register failed: weak password";
        } else {
            Customer customer = new Customer(username, password);
            Snapp.addCustomer(customer);
            return "register successful";
        }
    }

    public static String login(Matcher matcher) {
        matcher.find();
        String username = matcher.group("username");
        String password = matcher.group("password");
        if (Snapp.getUserByName(username) == null) {
            return "login failed: username not found";
        } else if (!Snapp.getUserByName(username).getPassword().equals(password)) {
            return "login failed: incorrect password";
        } else {
            return "login successful";
        }
    }

    public static String changePassword(Matcher matcher) {
        matcher.find();
        String username = matcher.group("username");
        String oldPass = matcher.group("old");
        String newPass = matcher.group("new");
        if (Snapp.getUserByName(username) == null) {
            return "password change failed: username not found";
        } else if (!Snapp.getUserByName(username).getPassword().equals(oldPass)) {
            return "password change failed: incorrect password";
        }else if (!newPass.matches("\\w+")) {
            return "password change failed: invalid new password";
        } else if (!newPass.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{5,}$")) {
            return "password change failed: weak new password";
        } else {
            Snapp.getUserByName(username).setPassword(newPass);
            return "password change successful";
        }
    }

    public static String removeAccount(Matcher matcher) {
        matcher.find();
        String username = matcher.group("username");
        String password = matcher.group("password");
        if (Snapp.getCustomerByName(username) == null) {
            return "remove account failed: username not found";
        } else if (!Snapp.getCustomerByName(username).getPassword().equals(password)) {
            return "remove account failed: incorrect password";
        } else {
            Snapp.removeCustomer(Snapp.getCustomerByName(username));
            return "remove account successful";
        }
    }
}
