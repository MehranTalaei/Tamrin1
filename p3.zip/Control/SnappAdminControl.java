package Control;

import Model.Discount;
import Model.Restaurant;
import Model.Snapp;

import java.util.regex.Matcher;

public class SnappAdminControl {
    public static String addRest(Matcher matcher) {
        matcher.find();
        String username = matcher.group("name");
        String password = matcher.group("password");
        String type = matcher.group("type");
        if (!username.matches("\\w+")) {
            return "add restaurant failed: invalid username format";
        } else if (username.matches("[0-9_]+")) {
            return "add restaurant failed: invalid username format";
        } else if (Snapp.getUserByName(username) != null) {
            return "add restaurant failed: username already exists";
        }  else if (!password.matches("\\w+")) {
            return "add restaurant failed: invalid password format";
        } else if (!password.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z]).{5,}$")) {
            return "add restaurant failed: weak password";
        } else if (!type.matches("[a-z-]+")) {
            return "add restaurant failed: invalid type format";
        } else {
            Restaurant restaurant = new Restaurant(username, password, type);
            Snapp.addRestaurant(restaurant);
            return "add restaurant successful";
        }
    }

    public static String showRest(Matcher matcher) {
        matcher.find();
        String type = matcher.group("type");
        String s = new String();
        int counter = 0;
        for (Restaurant restaurant : Snapp.getRestaurants()) {
            if (type == null || restaurant.getType().equals(type)) {
                counter++;
                if (restaurant.getType() != null) {
                    s += (counter + ") " + restaurant.getUsername() + ": type=" + restaurant.getType() +
                            " balance=" + restaurant.getBalance());
                    s += "\n";
                } else {
                    s += (counter + ") " + restaurant.getUsername() +
                            " balance=" + restaurant.getBalance());
                    s += "\n";
                }
            }
        }
        return s;
    }

    public static String removeRest(Matcher matcher) {
        matcher.find();
        String name = matcher.group("name");
        if (Snapp.getRestaurantByname(name) == null) {
            return "remove restaurant failed: restaurant not found";
        } else {
            Snapp.getRestaurants().remove(Snapp.getRestaurantByname(name));
            return "";
        }
    }

    public static String setDiscount(Matcher matcher) {
        matcher.find();
        String username = matcher.group("username");
        int amount = Integer.parseInt(matcher.group("amount"));
        String code = matcher.group("code");
        if (Snapp.getCustomerByName(username) == null) {
            return "set discount failed: username not found";
        } else if (amount<=0) {
            return "set discount failed: invalid amount";
        } else if (!code.matches("[a-zA-Z0-9]+")) {
            return "set discount failed: invalid code format";
        } else {
            Discount discount = new Discount(Snapp.getCustomerByName(username), code, amount);
            Snapp.addDiscount(discount);
            Snapp.getCustomerByName(username).addDisccout(discount);
            return "set discount successful";
        }
    }

    public static String showDiscounts(Matcher matcher) {
        matcher.find();
        int counter = 0;
        String s = new String();
        for (Discount discount : Snapp.getDiscounts()) {
            counter++;
            s += (counter + ") " + discount.getCode() + " | amount=" + discount.getAmount() +
                    " --> user=" + discount.getOwner().getUsername() + "\n");
        }
        return s;
    }
}
