package Control;

import Model.*;

import java.util.regex.Matcher;

public class CustomerControl {
    public static String showRests(Matcher matcher, Customer customer) {
        matcher.find();
        String type = matcher.group("type");
        String s = new String();
        int counter = 0;
        for (Restaurant restaurant : Snapp.getRestaurants()) {
            if (restaurant.getType().equals(type) || type == null) {
                counter++;
                if (restaurant.getType() != null) {
                    s += (counter + ") " + restaurant.getUsername() + ": type=" + restaurant.getType());
                } else {
                    s += (counter + ") " + restaurant.getUsername());
                }
                s += "\n";
            }
        }
        return s;
    }

    public static String ShowMenu(Matcher matcher, Customer customer) {
        matcher.find();
        String name = matcher.group("name");
        String category = matcher.group("category");
        String ans = new String();
        if (Snapp.getRestaurantByname(name) == null) {
            return "show menu failed: restaurant not found\n";
        }
        if (!Restaurant.categories.contains(category) && category != null) {
            return "show menu failed: invalid category\n";
        }
        if (category == null) {
            ans += "<< STARTER >>\n";
            for (Food food : Snapp.getRestaurantByname(name).getMenu()) {
                if (food.getCategory().equals("starter")) {
                    ans += (food.getName() + " | price=" + food.getPrice());
                    ans += "\n";
                }
            }
            ans += "<< ENTREE >>\n";
            for (Food food : Snapp.getRestaurantByname(name).getMenu()) {
                if (food.getCategory().equals("entree")) {
                    ans += (food.getName() + " | price=" + food.getPrice());
                    ans += "\n";
                }
            }
            ans += "<< DESSERT >>\n";
            for (Food food : Snapp.getRestaurantByname(name).getMenu()) {
                if (food.getCategory().equals("dessert")) {
                    ans += (food.getName() + " | price=" + food.getPrice());
                    ans += "\n";
                }
            }
        } else {
            for (Food food : Snapp.getRestaurantByname(name).getMenu()) {
                if (food.getCategory().equals(category)) {
                    ans += (food.getName() + " | price=" + food.getPrice());
                    ans += "\n";
                }
            }
        }
        return ans;
    }

    public static String addToCart(Matcher matcher, Customer customer) {
        matcher.find();
        String name = matcher.group("name");
        String food = matcher.group("food");
        int number;
        if (matcher.group("number") != null) {
            number = Integer.parseInt(matcher.group("number"));
        }else {
            number = 1;}

        if (Snapp.getRestaurantByname(name) == null) {
            return "add to cart failed: restaurant not found";
        }
        Restaurant restaurant = Snapp.getRestaurantByname(name);
        if (restaurant.getFoodByName(food) == null) {
            return "add to cart failed: food not found";
        }
        if (number <= 0) {
            return "add to cart failed: invalid number";
        }
        if (customer.FindFood(restaurant.getFoodByName(food)) == null) {
            FoodOrdered foodOrdered = new FoodOrdered(restaurant.getFoodByName(food), customer, number);
            customer.addToCart(foodOrdered);
        } else {
            customer.FindFood(restaurant.getFoodByName(food)).increaseNumber(number);
        }
        return "add to cart successful";
    }

    public static String removeFromCart(Matcher matcher, Customer customer) {
        matcher.find();
        String name = matcher.group("name");
        String food = matcher.group("food");
        int number;
        if (matcher.group("number") != null) {
            number = Integer.parseInt(matcher.group("number"));
        }else {
            number = 1;}

        if (Snapp.getRestaurantByname(name) == null) {
            return "remove from cart failed: not in cart";
        }
        Restaurant restaurant = Snapp.getRestaurantByname(name);
        if (restaurant.getFoodByName(food) == null) {
            return "remove from cart failed: not in cart";
        }
        Food currentFood = restaurant.getFoodByName(food);
        if (customer.FindFood(currentFood) == null) {
            return "remove from cart failed: not in cart";
        }
        if (number <= 0) {
            return "remove from cart failed: invalid number";
        }
        if (customer.FindFood(currentFood).getNumber() < number) {
            return "remove from cart failed: not enough food in cart";
        }
        customer.FindFood(currentFood).increaseNumber(-number);
        if (customer.FindFood(currentFood).getNumber() == 0) {
            customer.getCart().remove(customer.FindFood(currentFood));
        }
        return "remove from cart successful";
    }

    public static String showCart(Matcher matcher, Customer customer) {
        String ans=new String();
        int counter = 0;
        int total=0;
        for (FoodOrdered foodOredered : customer.getCart()) {
            counter++;
            ans += (counter + ") " + foodOredered.getFood().getName() + " | restaurant=" +
                    foodOredered.getFood().getRestaurant().getUsername() +
                    " price=" + foodOredered.getFood().getPrice() * foodOredered.getNumber()
            );
            ans += "\n";
            total += foodOredered.getFood().getPrice() * foodOredered.getNumber();
        }
        ans += ("Total: " + total);
        ans += "\n";
        return ans;
    }

    public static String showDiscounts(Matcher matcher, Customer customer) {
        String ans = new String();
        int counter=0;
        for (Discount discount : customer.getDiscounts()) {
            counter++;
            ans += (counter + ") " + discount.getCode() + " | amount=" + discount.getAmount());
            ans += "\n";
        }
        return ans;
    }

    public static String purchase(Matcher matcher, Customer customer) {
        matcher.find();
        String Code = matcher.group("code");
        if (Code != null && customer.getDiscountByCode(Code) == null) {
            return "purchase failed: invalid discount code";
        }
        if (Code == null && customer.getBalance() < customer.GetTotalPriceOfCart()) {
            return "purchase failed: inadequate money";
        }
        if (Code != null && customer.getBalance() < customer.GetTotalPriceOfCart() - customer.getDiscountByCode(Code).getAmount()) {
            return "purchase failed: inadequate money";
        } else {
            if (Code != null) {
                customer.increaseBalance(customer.getDiscountByCode(Code).getAmount());
                Snapp.getDiscounts().remove(customer.getDiscountByCode(Code));
                customer.getDiscounts().remove(customer.getDiscountByCode(Code));
            }
            for (FoodOrdered foodOrdered : customer.getCart()) {
                Restaurant restaurant=foodOrdered.getFood().getRestaurant();
                restaurant.increaseBalance((foodOrdered.getFood().getPrice() - foodOrdered.getFood().getCost())*foodOrdered.getNumber());
                customer.increaseBalance(-foodOrdered.getFood().getPrice()*foodOrdered.getNumber());
            }
            customer.getCart().clear();
            return "purchase successful";
        }
    }
}
