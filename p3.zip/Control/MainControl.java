package Control;

import Model.User;

import java.util.regex.Matcher;

public class MainControl {
    User user;
    public static void EnterMenu(Matcher matcher) {
        matcher.find();
    }
}
