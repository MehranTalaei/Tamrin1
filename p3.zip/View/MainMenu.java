package View;

import Model.*;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainMenu {
    User currentUser;
    Pattern enterMenu = Pattern.compile("\\s*enter\\s+(?<menu>.+)\\s*");
    Pattern logout = Pattern.compile("\\s*logout\\s*");
    Pattern showMenu = Pattern.compile("\\s*show\\s+current\\s+menu\\s*");
    public void run(Scanner scanner) {
        String command=scanner.nextLine();
        if (command.matches(enterMenu.pattern())) {
            Matcher matcher = enterMenu.matcher(command);
            matcher.find();
            String menu = matcher.group("menu");
            menu=menu.trim();
            if (menu.length() == 0) {
                System.out.println("invalid command!");
                this.run(scanner);
            }
            if (!menu.matches("Snappfood\\s+admin\\s+menu")&&
                    !menu.matches("restaurant\\s+admin\\s+menu")&&
                    !menu.matches("customer\\s+menu")) {
                System.out.println("enter menu failed: invalid menu name");
                this.run(scanner);
            } else if (menu.matches("Snappfood\\s+admin\\s+menu") && (!(currentUser instanceof SnappAdmin))) {
                System.out.println("enter menu failed: access denied");
                this.run(scanner);
            } else if (menu.matches("restaurant\\s+admin\\s+menu") && (!(currentUser instanceof Restaurant))) {
                System.out.println("enter menu failed: access denied");
                this.run(scanner);
            } else if (menu.matches("customer\\s+menu") && (!(currentUser instanceof Customer))) {
                System.out.println("enter menu failed: access denied");
                this.run(scanner);
            } else {
                if (menu.matches("Snappfood\\s+admin\\s+menu")) {
                    menu = "Snappfood admin menu";
                    System.out.println("enter menu successful: You are in the " + menu + "!");
                    SnappAdminMenu snappAdminMenu = new SnappAdminMenu(currentUser);
                    snappAdminMenu.run(scanner);
                }
                if (menu.matches("restaurant\\s+admin\\s+menu")) {
                    menu = "restaurant admin menu";
                    System.out.println("enter menu successful: You are in the " + menu + "!");
                    RestaurantMenu restaurantMenu = new RestaurantMenu(currentUser);
                    restaurantMenu.run(scanner);
                }
                if (menu.matches("customer\\s+menu")) {
                    menu = "customer menu";
                    System.out.println("enter menu successful: You are in the " + menu + "!");
                    CustomerMenu customerMenu = new CustomerMenu(currentUser);
                    customerMenu.run(scanner);
                }
            }
        }
        else if (command.matches(logout.pattern())) {
            RegisterMenu registerMenu = new RegisterMenu();
            registerMenu.run(scanner);
        } else if (command.matches(showMenu.pattern())) {
            System.out.println("main menu");
            this.run(scanner);
        } else {
            System.out.println("invalid command!");
            this.run(scanner);
        }
    }
    public MainMenu(User currentUser) {
        this.currentUser = currentUser;
    }
}
