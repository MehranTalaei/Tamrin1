package View;

import Control.RestControll;
import Control.SnappAdminControl;
import Model.Restaurant;
import Model.SnappAdmin;
import Model.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RestaurantMenu {
    Pattern chargeAccount = Pattern.compile("\\s*charge\\s+account\\s+(?<amount>-?\\d+)\\s*");
    Pattern showBalance = Pattern.compile("\\s*show\\s+balance\\s*");
    Pattern addFood = Pattern.compile("\\s*add\\s+food\\s+(?<name>\\S+)\\s+(?<category>\\S+)\\s+(?<price>-?\\d+)\\s+(?<cost>-?\\d+)\\s*");
    Pattern removeFood = Pattern.compile("\\s*remove\\s+food\\s+(?<name>\\S+)\\s*");
    Pattern logout = Pattern.compile("\\s*logout\\s*");
    Pattern showMenu = Pattern.compile("\\s*show\\s+current\\s+menu\\s*");
    User currentUser;

    public void run(Scanner scanner) {
        String command = scanner.nextLine();
        if (command.matches(chargeAccount.pattern())) {
            Matcher matcher = chargeAccount.matcher(command);
            String output = RestControll.Charge(matcher, ((Restaurant) currentUser));
            System.out.println(output);
            this.run(scanner);
        }
        else if (command.matches(showBalance.pattern())) {
            Matcher matcher = showBalance.matcher(command);
            String output = RestControll.ShowBalance(matcher, ((Restaurant) currentUser));
            System.out.println(output);
            this.run(scanner);
        }
        else if (command.matches(addFood.pattern())) {
            Matcher matcher = addFood.matcher(command);
            String output = RestControll.addFood(matcher, ((Restaurant) currentUser));
            System.out.println(output);
            this.run(scanner);
        }
        else if (command.matches(removeFood.pattern())) {
            Matcher matcher = removeFood.matcher(command);
            String output = RestControll.removeFood(matcher, ((Restaurant) currentUser));
            if(output.length()>0)
                System.out.println(output);
            this.run(scanner);
        }
        else if (command.matches(logout.pattern())) {
            RegisterMenu registerMenu=new RegisterMenu();
            registerMenu.run(scanner);
        }
        else if (command.matches(showMenu.pattern())) {
            System.out.println("restaurant admin menu");
            this.run(scanner);
        }
        else {
            System.out.println("invalid command!");
            this.run(scanner);
        }


    }

    public RestaurantMenu(User currentUser) {
        this.currentUser = currentUser;
    }
}
