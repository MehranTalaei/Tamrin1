package View;

import Control.RegisterControl;
import Model.Customer;
import Model.Restaurant;
import Model.Snapp;
import Model.SnappAdmin;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegisterMenu {

    Pattern register = Pattern.compile("\\s*register\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*");
    Pattern login = Pattern.compile("\\s*login\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*");
    Pattern removeAccount = Pattern.compile("\\s*remove\\s+account\\s+(?<username>\\S+)\\s+(?<password>\\S+)\\s*");
    Pattern changePassword = Pattern.compile("\\s*change\\s+password\\s+(?<username>\\S+)\\s+(?<old>\\S+)\\s+(?<new>\\S+)\\s*");
    Pattern showMenu = Pattern.compile("\\s*show\\s+current\\s+menu\\s*");
    Pattern exit = Pattern.compile("\\s*exit\\s*");

    public void Start(Scanner scanner) {
        String username=scanner.nextLine();
        String password=scanner.nextLine();
        SnappAdmin.SetInstance(username, password);
    }

    public void run(Scanner scanner) {
        String command=scanner.nextLine();
        if (command.matches(register.pattern())) {
            Matcher mat = register.matcher(command);
            String output = RegisterControl.register(mat);
            System.out.println(output);
            this.run(scanner);
        } else if (command.matches(login.pattern())) {
            Matcher mat = login.matcher(command);
            String ouput = RegisterControl.login(mat);
            System.out.println(ouput);
            if (ouput.matches("login successful")) {
                mat = login.matcher(command);
                mat.find();
                String username = mat.group("username");
                String password = mat.group("password");
                for (int i = 0; i < Snapp.getCustomers().size(); i++) {
                    Customer customer = Snapp.getCustomers().get(i);
                    if (customer.getPassword().equals(password) && customer.getUsername().equals(username)) {
                        MainMenu mainMenu = new MainMenu(customer);
                        mainMenu.run(scanner);
                    }
                }
                for (Restaurant restaurant : Snapp.getRestaurants()) {
                    if (restaurant.getPassword().equals(password) && restaurant.getUsername().equals(username)) {
                        MainMenu mainMenu = new MainMenu(restaurant);
                        mainMenu.run(scanner);
                    }
                }
                if (SnappAdmin.getInstance().getPassword().equals(password) && SnappAdmin.getInstance().getUsername().equals(username)) {
                    MainMenu mainMenu = new MainMenu(SnappAdmin.getInstance());
                    mainMenu.run(scanner);
                }
            } else {
                this.run(scanner);
            }
        }else if (command.matches(removeAccount.pattern())) {
            Matcher mat = removeAccount.matcher(command);
            String output = RegisterControl.removeAccount(mat);
            System.out.println(output);
            this.run(scanner);
        }else if (command.matches(changePassword.pattern())) {
            Matcher mat = changePassword.matcher(command);
            String output = RegisterControl.changePassword(mat);
            System.out.println(output);
            this.run(scanner);
        }else if (command.matches(showMenu.pattern())) {
            System.out.println("login menu");
            this.run(scanner);
        } else if (command.matches(exit.pattern())) {
            return;
        } else {
            System.out.println("invalid command!");
            this.run(scanner);
        }
    }
}
