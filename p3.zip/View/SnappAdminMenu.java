package View;

import Control.SnappAdminControl;
import Model.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class SnappAdminMenu {
    Pattern addRes = Pattern.compile("\\s*add\\s+restaurant\\s+(?<name>\\S*)\\s+(?<password>\\S*)\\s+(?<type>\\S*)\\s*");
    Pattern showList = Pattern.compile("\\s*show\\s+restaurant(\\s+-t\\s+(?<type>\\S+))?\\s*");
    Pattern removeRes = Pattern.compile("\\s*remove\\s+restaurant\\s+(?<name>\\S*)\\s*");
    Pattern setDiscount = Pattern.compile("\\s*set\\s+discount\\s+(?<username>\\S*)\\s+(?<amount>-?\\d*)\\s+(?<code>\\S*)\\s*");
    Pattern showDiscounts = Pattern.compile("\\s*show\\s+discounts\\s*");
    Pattern logout = Pattern.compile("\\s*logout\\s*");
    Pattern showMenu = Pattern.compile("\\s*show\\s+current\\s+menu\\s*");
    User currentUser;

    public void run(Scanner scanner) {
        String command = scanner.nextLine();
        if (command.matches(addRes.pattern())) {
            Matcher matcher = addRes.matcher(command);
            String output = SnappAdminControl.addRest(matcher);
            System.out.println(output);
            this.run(scanner);
        }
        else if (command.matches(showList.pattern())) {
            Matcher matcher = showList.matcher(command);
            String output = SnappAdminControl.showRest(matcher);
            System.out.print(output);
            this.run(scanner);
        }
        else if (command.matches(removeRes.pattern())) {
            Matcher matcher =removeRes.matcher(command);
            String output = SnappAdminControl.removeRest(matcher);
            if (output.length() > 0) {
                System.out.println(output);
            }
            this.run(scanner);
        }
        else if (command.matches(setDiscount.pattern())) {
            Matcher matcher = setDiscount.matcher(command);
            String output = SnappAdminControl.setDiscount(matcher);
            System.out.println(output);
            this.run(scanner);
        }
        else if (command.matches(showDiscounts.pattern())) {
            Matcher matcher = showDiscounts.matcher(command);
            String output = SnappAdminControl.showDiscounts(matcher);
            System.out.print(output);
            this.run(scanner);
        }
        else if (command.matches(logout.pattern())) {
            RegisterMenu registerMenu=new RegisterMenu();
            registerMenu.run(scanner);
        }
        else if (command.matches(showMenu.pattern())) {
            System.out.println("Snappfood admin menu");
            this.run(scanner);
        }
        else {
            System.out.println("invalid command!");
            this.run(scanner);
        }
    }
    public SnappAdminMenu(User currentUser) {
        this.currentUser = currentUser;
    }
}
