package View;

import Control.CustomerControl;
import Control.RestControll;
import Model.Customer;
import Model.Restaurant;
import Model.SnappAdmin;
import Model.User;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CustomerMenu {
    Pattern showList = Pattern.compile("\\s*show\\s+restaurant(\\s+-t\\s+(?<type>\\S+))?\\s*");
    Pattern showMenu = Pattern.compile("\\s*show\\s+menu\\s+(?<name>\\S*)(\\s+-c\\s+(?<category>\\S+))?\\s*");
    Pattern addToCart = Pattern.compile("\\s*add\\s+to\\s+cart\\s+(?<name>\\S*)\\s+(?<food>\\S+)(\\s+-n\\s+(?<number>-?\\d+))?\\s*");
    Pattern removerFromCart = Pattern.compile("\\s*remove\\s+from\\s+cart\\s+(?<name>\\S*)\\s+(?<food>\\S+)(\\s+-n\\s+(?<number>-?\\d+))?\\s*");
    Pattern showCart = Pattern.compile("\\s*show\\s+cart\\s*");
    Pattern showDiscounts = Pattern.compile("\\s*show\\s+discounts\\s*");
    Pattern purchase = Pattern.compile("\\s*purchase\\s+cart(\\s+-d\\s+(?<code>\\S+))?\\s*");
    Pattern logout = Pattern.compile("\\s*logout\\s*");
    Pattern showCurrentMenu = Pattern.compile("\\s*show\\s+current\\s+menu\\s*");
    Pattern chargeAccount = Pattern.compile("\\s*charge\\s+account\\s+(?<amount>-?\\d+)\\s*");
    Pattern showBalance = Pattern.compile("\\s*show\\s+balance\\s*");

    User user;

    public void run(Scanner scanner) {
        String command = scanner.nextLine();
        if (command.matches(showList.pattern())) {
            Matcher matcher = showList.matcher(command);
            String output = CustomerControl.showRests(matcher, (((Customer) user)));
            System.out.print(output);
            this.run(scanner);
        }
        else if (command.matches(showMenu.pattern())) {
            Matcher matcher = showMenu.matcher(command);
            String output = CustomerControl.ShowMenu(matcher, (((Customer) user)));
            System.out.print(output);
            this.run(scanner);
        }
        else if (command.matches(addToCart.pattern())) {
            Matcher matcher = addToCart.matcher(command);
            String output = CustomerControl.addToCart(matcher, (((Customer) user)));
            System.out.println(output);
            this.run(scanner);
        }
        else if (command.matches(removerFromCart.pattern())) {
            Matcher matcher = removerFromCart.matcher(command);
            String output = CustomerControl.removeFromCart(matcher, (((Customer) user)));
            System.out.println(output);
            this.run(scanner);
        }
        else if (command.matches(showCart.pattern())) {
            Matcher matcher = showCart.matcher(command);
            String output = CustomerControl.showCart(matcher, (((Customer) user)));
            System.out.print(output);
            this.run(scanner);
        }
        else if (command.matches(showDiscounts.pattern())) {
            Matcher matcher = showDiscounts.matcher(command);
            String output = CustomerControl.showDiscounts(matcher, (((Customer) user)));
            System.out.print(output);
            this.run(scanner);
        }
        else if (command.matches(purchase.pattern())) {
            Matcher matcher = purchase.matcher(command);
            String output = CustomerControl.purchase(matcher, (((Customer) user)));
            System.out.println(output);
            this.run(scanner);
        }
        else if (command.matches(chargeAccount.pattern())) {
            Matcher matcher = chargeAccount.matcher(command);
            String output = RestControll.Charge(matcher, (user));
            System.out.println(output);
            this.run(scanner);
        }
        else if (command.matches(showBalance.pattern())) {
            Matcher matcher = showBalance.matcher(command);
            String output = RestControll.ShowBalance(matcher, (user));
            System.out.println(output);
            this.run(scanner);
        }
        else if (command.matches(logout.pattern())) {
            RegisterMenu registerMenu=new RegisterMenu();
            registerMenu.run(scanner);
        }
        else if (command.matches(showCurrentMenu.pattern())) {
            System.out.println("customer menu");
            this.run(scanner);
        }
        else {
            System.out.println("invalid command!");
            this.run(scanner);
        }
    }

    public CustomerMenu(User user) {
        this.user = user;
    }
}
