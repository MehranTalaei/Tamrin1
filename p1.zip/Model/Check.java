package Model;

public class Check {
    String s;

    public String getS() {
        return s;
    }
}
