package ViewAndControler;

import Model.*;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginMenu {
    static Pattern loginCommand = Pattern.compile("login i (?<id>\\S+) p (?<password>\\S+)");
    static Pattern registerCommand = Pattern.compile("register i (?<id>\\S+) u (?<username>\\S+) p (?<password>\\S+)");
    static Pattern exit = Pattern.compile("exit");
    public void run(Scanner scanner) {

        String command = scanner.nextLine();
        if (command.matches(exit.pattern())) {
            return;
        }
        else if (command.matches(registerCommand.pattern())) {
            System.out.println(register(registerCommand.matcher(command)));
            this.run(scanner);
        }
        else if (command.matches(loginCommand.pattern())) {
            String output = login(loginCommand.matcher(command));
            System.out.println(output);
            if (output.equals("User successfully logged in!")) {
                MessageMenu messageMenu = new MessageMenu();
                Matcher mat=loginCommand.matcher(command);
                mat.find();
                String id = mat.group("id");
                User current = Messenger.getUserById(id);
                messageMenu.setCurrentUser(current);
                messageMenu.run(scanner);
            } else {
                this.run(scanner);
            }
        }
        else {
            System.out.println("Invalid command!");
            this.run(scanner);
        }
        return;
    }

    private String login(Matcher matcher) {
        matcher.find();
        String password = matcher.group("password");
        String id = matcher.group("id");
        if (Messenger.getUserById(id) == null) {
            return "No user with this id exists!";
        } else if (!Messenger.getUserById(id).getPassword().equals(password)) {
            return "Incorrect password!";
        } else {
            return "User successfully logged in!";
        }
    }

    private String register(Matcher matcher) {
        matcher.find();
        String password = matcher.group("password");
        String id = matcher.group("id");
        String username = matcher.group("username");
        if (!username.matches("\\w+")) {
            return "Username's format is invalid!";
        } else if (!password.matches("^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[\\*\\.\\!\\@\\$\\%\\^\\&\\(\\)\\{\\}\\[\\]\\:\\;\\<\\>\\,\\?\\/\\~\\_\\+\\-\\=\\|]).{8,32}$")) {
            return "Password is weak!";
        } else if (Messenger.getUserById(id) != null) {
            return "A user with this ID already exists!";
        } else {
            User newUser = new User(id, username, password);
            Messenger.addUser(newUser);
            return "User has been created successfully!";
        }
    }

}
